import plotly.graph_objects as go
import plotly.express as px
import plotly.io as pio
from datetime import datetime
from dateutil.relativedelta import relativedelta
from .config import *
from .ReefOps import time_stage_label
import pandas as pd
from .ReefOps import *
from S3 import Storage
import numpy as np


def month_diff(date1, date2):
    days_delta = (date2 - date1).days
    return days_delta / 365


class ReefSFM:
    s3_storage = Storage(name='archireef-hive')
    reef_metrics_s3 = s3_storage.read_file(file_path=REEF_METRICS_DB)
    coral_metrics_s3 = s3_storage.read_file(file_path=CORAL_METRICS_DB)

    def __init__(self, site_id, survey_id, wr_bucket='archireef-hive'):
        self.site_id = site_id
        self.survey_id = survey_id
        self.output_bucket = Storage(name=wr_bucket)
        site = Site(site_id=self.site_id)
        survey = Survey(site=site, survey_id=self.survey_id)
        # Read ReefSFM data
        reef_metrics_obj = io.BytesIO(ReefSFM.reef_metrics_s3)
        coral_metrics_obj = io.BytesIO(ReefSFM.coral_metrics_s3)
        self.reef_metrics_db = pd.read_csv(reef_metrics_obj, index_col=0).reset_index()
        self.coral_metrics_db = pd.read_csv(coral_metrics_obj, index_col=0).reset_index()
        self.current_coral_metrics = self.coral_metrics_db[
            (self.coral_metrics_db.survey_id == self.survey_id) & (self.coral_metrics_db.site_id == self.site_id)]
        self.baseline_coral_metrics = self.coral_metrics_db[
            (self.coral_metrics_db.survey_id == survey.baseline_id) & (self.coral_metrics_db.site_id == self.site_id)]
        self.current_reef_metrics = self.reef_metrics_db[
            (self.reef_metrics_db.survey_id == self.survey_id) & (self.reef_metrics_db.site_id == self.site_id)].iloc[0]
        self.baseline_reef_metrics = self.reef_metrics_db[(self.reef_metrics_db.survey_id == survey.baseline_id) & (
                    self.reef_metrics_db.site_id == self.site_id)].iloc[0]

        if survey.baseline_id != survey.survey_id:
            self.composition_df = pd.concat([self.current_coral_metrics, self.baseline_coral_metrics],
                                            ignore_index=True)
        else:
            self.composition_df = self.current_coral_metrics

        self.coral_cover_df = self.reef_metrics_db[self.reef_metrics_db.site_id == self.site_id]

    def composition_plot(self, composition_plot_output=None, write_html=False):
        self.composition_df = self.composition_df.sort_values("survey_id")
        xlabels = ["Baseline", "Current"]
        sids = self.composition_df.survey_id.unique()
        dates = self.composition_df.date.unique()
        xlabels = [time_stage_label(xl, date, date_format=DATE_STR_FORMAT) for xl, date in zip(xlabels, dates)]

        xlabel_map = dict(zip(sids, xlabels))
        self.composition_df["xlabel"] = [xlabel_map[sid] for sid in self.composition_df.survey_id]

        # create italisized annotations for Genus names  
        annotations_text = [f"<i>{taxa}</i>" for taxa in self.composition_df.taxa]

        # Add composition bar plot
        fig = px.bar(self.composition_df,
                     x="xlabel",
                     y="composition",
                     color="taxa",
                     pattern_shape="taxa",
                     text=annotations_text,
                     barmode="stack",
                     hover_data=dict(taxa=False, xlabel=False),
                     color_discrete_sequence=COLORS,
                     pattern_shape_sequence=PATTERNS,
                     labels=dict(x="Time Stage",
                                 y="Composition (%)",
                                 composition="Composition",
                                 text="Genus")

                     )

        fig.update_traces(

            textfont_size=25,
            width=0.5,
            textposition="inside",
            marker=dict(
                line_color="grey",
                pattern_fillmode="replace"
            ),

        )

        fig.update_layout(
            uniformtext_minsize=8,
            uniformtext_mode='hide',
            barmode='stack',
            yaxis_title='Composition (%)',
            xaxis_title="Time Stage",
            yaxis_tickformat=".0%",
            hovermode="x",
            showlegend=False
        )

        fig.update_layout(BAR_PLOT_LAYOUT)
        fig.update_annotations(text="<i></i>")
        if write_html:
            # fig.write_html(LOCAL_COMPOSITION)
            # with open(LOCAL_COMPOSITION, 'r') as f:
            #     fig_html = f.read()
            fig_html = pio.to_html(fig)
            self.output_bucket.write_file(fig_html, output_path=composition_plot_output, html=True)
        else:
            return fig

    def survivorship_plot(self, survivorship_plot_output=None, write_html=False):
        data = []
        labels = []
        taxa = []
        healthy = [x for x in self.current_coral_metrics.percent_healthy]
        healthy_l = ["healthy" for x in self.current_coral_metrics.percent_healthy]
        bleached = [x for x in self.current_coral_metrics.percent_bleached]
        bleached_l = ["bleached" for x in self.current_coral_metrics.percent_bleached]
        dead = [x for x in self.current_coral_metrics.percent_dead]
        dead_l = ["dead" for x in self.current_coral_metrics.percent_dead]

        data.extend(healthy)
        data.extend(bleached)
        data.extend(dead)
        labels.extend(healthy_l)
        labels.extend(bleached_l)
        labels.extend(dead_l)

        for i in range(0, 3):
            taxa.extend(self.current_coral_metrics.taxa.to_list())
        current_health_metrics = pd.DataFrame(dict(taxa=taxa, value=data, status=labels))

        colors = COLORS[0:len(current_health_metrics)]
        patterns = ["", "x", "/"]
        # Italicize coral genus 
        x = [f"<i>{taxa}</i>" for taxa in current_health_metrics.taxa]
        current_health_metrics.status = ["Live" if status == "healthy" else status.title() for status in
                                         current_health_metrics.status]
        fig = px.bar(
            current_health_metrics,
            x=x,
            y="value",
            color="taxa",
            pattern_shape="status",
            hover_data=dict(taxa=False, ),
            color_discrete_sequence=colors,
            pattern_shape_sequence=patterns,
            text="status",
            labels=dict(x="Coral Genus",
                        y="Survivorship (%)",
                        status="Status",
                        value="Value",
                        taxa="Coral Genus")
        )

        fig.update_layout(
            hovermode="x unified",
            yaxis_title='Survivorship (%)',
            xaxis_title="Coral Genus",
            yaxis_tickformat=".0%",
            showlegend=False,
            hoverlabel=dict(
                bgcolor="white"
            )
        )
        fig.update_traces(
            width=0.5,
            textposition="inside",
            textfont=dict(
                # family="sans serif",
                # size=18,
                color="white"
            ),
            marker=dict(
                line_color="grey",
                pattern_fillmode="replace"),

        )

        fig.update_layout(BAR_PLOT_LAYOUT)
        fig.update_layout(font=dict(family="Lexend"))
        if write_html:
            # fig.write_html(LOCAL_SURVIVORSHIP)
            # with open(LOCAL_SURVIVORSHIP, 'r') as f:
            #     fig_html = f.read()
            fig_html = pio.to_html(fig)
            self.output_bucket.write_file(fig_html, output_path=survivorship_plot_output, html=True)
        else:
            return fig

    def model_coral_cover(self, coral_cover_plot_output=None, forecast_period=10, write_html=False):
        coral_cover_range = self.coral_cover_df[self.coral_cover_df.survey_id <= self.survey_id]
        coral_cover_range.date = [datetime.strptime(date, DATE_STR_FORMAT) for date in coral_cover_range.date]
        coral_cover_range = coral_cover_range.sort_values("date")
        start_date = coral_cover_range.date.iloc[0]
        total_quarters = forecast_period * 4
        # end_date = start_date + relativedelta(months=total_months)
        quarters = [start_date + relativedelta(months=3 * m) for m in range(1, round(total_quarters))]
        quarters.insert(0, start_date)

        base = coral_cover_range.cover.iloc[0]  # Attain baseline data

        # Coral Cover increase rates - divided by 4 to accomodate for quarterly time bins
        rate_factor_q = np.arange(0, forecast_period, 0.25)
        rate = 0.03  # Coral cover increase rate: 2-4%/yr (Lourey et al. 2000)
        rate_high = 0.05  # +1.5 C Scenario
        rate_low = 0.01  # -1.5 C Scenario

        start_year = coral_cover_range.year[0]
        end_year = start_year + forecast_period

        modelled_cover = [base * (1 + rate) ** rate_q for rate_q in rate_factor_q]  # Assume consistent recovery

        # +1.5 C Scenario
        scenario1 = [base * (1 + rate_low) ** rate_q for rate_q in rate_factor_q]

        # -1.5 C Scenario
        scenario2 = [base * (1 + rate_high) ** rate_q for rate_q in rate_factor_q]

        start_date = coral_cover_range.date[0]
        third_yr = start_date + relativedelta(years=3)

        fig = go.Figure([
            go.Scatter(
                name=f'{forecast_period}-yr Projection',
                x=quarters,
                y=modelled_cover,
                mode='markers+lines',
                line=dict(color='#0B4B7A'),
                # hovertemplate = "%{y:.00%}"
            ),
            go.Scatter(
                name='Current State',
                x=quarters,
                y=coral_cover_range['cover'],
                mode='lines+markers',
                line=dict(color='#FBC85F'),
                # hovertemplate = "%{y:.00%}",
                marker=dict(size=12)
            ),
            go.Scatter(
                name='+1.5 °C',
                x=quarters,
                y=scenario1,
                mode='lines',
                marker=dict(color="#444"),
                line=dict(width=0),
                showlegend=False,
                # hovertemplate = "%{y:.00%}"
            ),
            go.Scatter(
                name='-1.5 °C',
                x=quarters,
                y=scenario2,
                marker=dict(color="#444"),
                line=dict(width=0),
                mode='lines',
                fillcolor='rgba(169, 185, 216, 0.3)',
                fill='tonexty',
                showlegend=False,
                # hovertemplate = "%{y:.00%}"
            )
        ])

        fig.add_vline(x=third_yr.timestamp() * 1000,
                      line_dash="dash", line_color="#B5684C", opacity=1, line_width=2,
                      annotation_text="End of 3rd year", annotation_position="top right", )
        fig.update_layout(
            yaxis_title='Coral Cover (%)',
            xaxis_title='Year',
            # yaxis_range=[0,0.05],
            yaxis_tickformat=".1%",
            hovermode="x"
        )
        fig.update_layout(BAR_PLOT_LAYOUT)
        fig.layout.template = 'simple_white'

        if write_html:
            # fig.write_html(LOCAL_CORAL_COVER)
            # with open(LOCAL_CORAL_COVER, 'r') as f:
            #     fig_html = f.read()
            fig_html = pio.to_html(fig)
            self.output_bucket.write_file(fig_html, output_path=coral_cover_plot_output, html=True)
        else:
            return fig
