import folium
# Set Global File Path variables

# DIRECTORY PATHS
ROOT = ".."
DATA = "database"
REPORTS=f"{DATA}/client_data"
# DATA= f"{ROOT}/data"
# ASSETS=f"{ROOT}/global_assets"
# INFO=f"{DATA}/info"
# IMAGES=f"images"

# PLOTS HOSTING READ HTML
PLOTS_ROOT = "./assets/components"

# LOGOS HOSTING READ HTML
LOGOS_ROOT = "./assets/logos"

# TILE AREA in m2
TILE_AREA = 0.173

COVER_TARGET=0.15
SURIVORSHIP_TARGET=95
RUGOSITY_TARGET=0.4

# DATE FORMAT
DATE_STR_FORMAT = "%d/%m/%Y"

# DATASETS
REEFCHECK_DATA = f"{DATA}/reef_check"
REEFOPS_DATA = f"{DATA}/reef_ops"
REEFSFM_DATA = f"{DATA}/reef_sfm"

CORAL_METRICS_DB=f"{REEFSFM_DATA}/reefsfm_db_coral_metrics.csv"
REEF_METRICS_DB=f"{REEFSFM_DATA}/reefsfm_db_reef_metrics.csv"

# Report Template
REPORT_TEMPLATE = f"{DATA}/report_tool/html_template/new_template.html"

# PLOTS
LOCAL_MAP = f"{ROOT}/report/components/maps/map.html"
LOCAL_COMMUNITY_PLOT = f"{ROOT}/report/components/plots/community_comparison.html"
# COMMUNITY_PLOT_WRITE_OUTPUT = f"{DATA}/report/components/plots/community_comparison.html"
# COMMUNITY_PLOT_READ_HTML = f"{ROOT}/components/plots/community_comparison.html"
# MAP_WRITE_OUTPUT = f"{DATA}/report/components/maps/map.html"
# MAP_READ_HTML= f"{ROOT}/components/maps/map.html"
# CORAL_MAP_READ_HTML=f"{ROOT}/components/maps/coral_map.html"
LOCAL_INDICATOR_PROP = f"{ROOT}/report/components/plots/indicator_proportion.html"
LOCAL_CORAL_COVER = f"{ROOT}/report/components/plots/coral_projection.html"
LOCAL_COMPOSITION = f"{ROOT}/report/components/plots/composition.html"
LOCAL_SURVIVORSHIP = f"{ROOT}/report/components/plots/survivorship.html"

COMMUNITY_READ_HTML = f"{PLOTS_ROOT}/charts/community_comparison.html"
INDICATOR_PROP_READ_HTML = f"{PLOTS_ROOT}/charts/indicator_proportion.html"
MAP_READ_HTML = f"{PLOTS_ROOT}/maps/map.html"
CORAL_MAP_READ_HTML = f"{PLOTS_ROOT}/maps/coral_map.html"
CORAL_COVER_READ_HTML = f"{PLOTS_ROOT}/charts/coral_projection.html"
COMPOSITION_READ_HTML = f"{PLOTS_ROOT}/charts/composition.html"
SURVIVORSHIP_READ_HTML = f"{PLOTS_ROOT}/charts/survivorship.html"

# IMAGES
# ICON = f"{DATA}/archireef_assets/ar_map_icon.png"
# ICON = f"{ROOT}/report/global_assets/images/ar_logo.png"
ICON = "assets/icons/ar_logo.png"
CLIENT_LOGO = f"{LOGOS_ROOT}/logo.svg"
ARCHIREEF_LOGO = f"{LOGOS_ROOT}/ARF_logo.svg"
#ASSET_IMAGES = f"{ASSETS}/images/"


agents = dict(
    JW="Jane Wong",
    VY="Vriko Yu",
    LZ="Lamisse Zerrouki",
    MY="Mohammad Younes",
    DT="Deniz Tekerek",
    JD="Juan Diego",
    DB="David Baker",
    HW="Haykey Wong",
    OW="Olivia Wu"

)

# SET GLOBAL COLOR PALETTE
COLORS =['#0B4B7A', "#D4D5D6", "#B6C9D7", "#FBCD6F", "#FBCD6F", "#C8E0E0", "#E5EAF4", "#E1C3B7","#85A5BC", "#BFBFC2" ]
PATTERNS = ["", "/", "", "", "/", "", "", "", "", ""]

BAR_PLOT_LAYOUT = dict(
    margin=dict(
        l=10,
        r=0,
        b=0,
        t=0,
        pad=2
    ),
    font=dict(size=20),
    font_family="Lexend",
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)',
    legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        ),
    hoverlabel=dict(
        font_size=16,
        font_family="Lexend"
    )
)

# Site Map Config
# Add custom base maps to folium
basemaps = {
    'Google Maps': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Maps',
        overlay = True,
        control = True
    ),
    'Google Satellite': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Satellite',
        overlay = True,
        control = True
    ),
    'Google Terrain': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Terrain',
        overlay = True,
        control = True
    ),
    'Google Satellite Hybrid': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Satellite',
        overlay = True,
        control = True
    ),
    'Esri Satellite': folium.TileLayer(
        tiles = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attr = 'Esri',
        name = 'Esri Satellite',
        overlay = True,
        control = True
    )
}


