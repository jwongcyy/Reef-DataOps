from setuptools import setup, find_packages

setup(
    name='polyp',
    version='1.0.0',
    packages=find_packages(),
    install_requires=[
        'boto3==1.34.20',
        'DateTime==5.2',
        'folium==0.15.0',
        'numpy==1.26.1',
        'pandas==2.1.2',
        'plotly==5.18.0',
        'matplotlib==3.8.3'
    ],
    author='Archireef',
    author_email='cloud@archireef.co',
    description='Python software for Archireef management and analysis of coral restoration data',
    license='Archireef LTD'
)
