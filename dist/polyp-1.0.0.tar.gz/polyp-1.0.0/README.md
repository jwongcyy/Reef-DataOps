# Archireef Polyp
## Core Python Software for Archireef Ecological Data Analytics


![Archireef Polyp Logo](logo/polyp_logo.png)


The Polyp library is a suite of data management, analysis and visualisation tools in Python for Archireef's operational and ecological data. The library consits of the following modules:

1. ReefOps - core module for Archireef Operational data such as Sites, Surveys, Clients and Agents. All analytical modules are dependent on ReefOps.
2. ReefCheck - analysis and visualisation module for fish and invertebrate data.
3. ReefSFM - analysis and visualisation module for coral data.
<!--- 4. TaxonDB - formatting for taxonomic data across ecological datasets. --->

## How To Install

You can install the package by following these steps:

* First clone the package repository into your project directory
    
   `git clone git@github.com:ArchiCloud/Polyp.git`
* Then you can install it using the package files in `dist` directory:
  * Install it using pre built package `whl`
    
    `pip install dist/polyp-1.0.0-py3-none-any.whl`
  * If for any reason `whl` package didn't work on your OS you can build the package with source distribution file
    
    `pip install dist/polyp-1.0.0.tar.gz`
* Finally, you only need to import the module you need to use from the package into your source code

    ```
      from polyp.ReefOps import *
      from polyp.ReefCheck import *
      from polyp.ReefSFM import *
    ```

**Note:** You need to copy `S3` module to your project directory which is required for using `polyp` package.


## Documentation

Coming Soon!
